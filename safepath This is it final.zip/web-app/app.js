function log(m){console.log(m);}
// === SafePath v5 Enhancements ===
let safepathCheckinTimerId = null;
let safepathCountdownTimeout = null;
let safepathCountdownInterval = null;

function startCheckinTimer(minutes) {
  clearCheckinTimer();
  if (typeof log === "function") {
    log("Check-in timer started for " + minutes + " minutes.");
  }
  safepathCheckinTimerId = setTimeout(() => {
    if (typeof log === "function") {
      log("Check-in timer expired. Starting SOS countdown.");
    }
    startSosWithCountdown(8);
  }, minutes * 60000);
}

function clearCheckinTimer() {
  if (safepathCheckinTimerId) {
    clearTimeout(safepathCheckinTimerId);
    safepathCheckinTimerId = null;
    if (typeof log === "function") {
      log("Check-in timer canceled.");
    }
  }
}

function startSosWithCountdown(seconds) {
  if (!seconds || seconds < 3) seconds = 5;
  if (safepathCountdownTimeout) {
    if (typeof log === "function") log("An SOS countdown is already running.");
    return;
  }
  let remaining = seconds;
  if (typeof log === "function") {
    log("SOS will send in " + remaining + " seconds unless canceled.");
  }
  const label = document.createElement("div");
  label.id = "safepath-countdown-label";
  label.className = "log-entry";
  label.innerHTML = "<strong>⏱ SOS countdown: " + remaining + "s</strong>";
  const logEl = document.getElementById("log");
  if (logEl) logEl.prepend(label);

  safepathCountdownInterval = setInterval(() => {
    remaining -= 1;
    const el = document.getElementById("safepath-countdown-label");
    if (el) el.innerHTML = "<strong>⏱ SOS countdown: " + remaining + "s</strong>";
    if (remaining <= 0 && safepathCountdownInterval) {
      clearInterval(safepathCountdownInterval);
      safepathCountdownInterval = null;
    }
  }, 1000);

  safepathCountdownTimeout = setTimeout(() => {
    safepathCountdownTimeout = null;
    const el = document.getElementById("safepath-countdown-label");
    if (el && el.parentNode) el.parentNode.removeChild(el);
    if (typeof log === "function") log("Sending SOS now.");
    if (typeof sendAlert === "function") sendAlert("sos");
  }, seconds * 1000);
}

function cancelSosCountdown() {
  if (safepathCountdownTimeout) {
    clearTimeout(safepathCountdownTimeout);
    safepathCountdownTimeout = null;
    if (safepathCountdownInterval) {
      clearInterval(safepathCountdownInterval);
      safepathCountdownInterval = null;
    }
    const el = document.getElementById("safepath-countdown-label");
    if (el && el.parentNode) el.parentNode.removeChild(el);
    if (typeof log === "function") log("SOS countdown canceled.");
  } else {
    if (typeof log === "function") log("No SOS countdown is active.");
  }
}

function openGuardianMode() {
  if (typeof log === "function") {
    log("Guardian mode opened (demo). In a full version this shows live route + status for a trusted contact.");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  try {
    const controlPanel = document.querySelector(".control-panel") || document.body;
    const card = document.createElement("section");
    card.className = "card";
    card.innerHTML = `
      <h2>Safety Automation (demo)</h2>
      <p class="hint">Use a quick check-in timer or SOS countdown so SafePath can watch the clock for you.</p>
      <div class="voice-row" style="margin-bottom:8px;">
        <button id="spCheckin10" class="btn btn-secondary btn-sm">Check-in in 10 min</button>
        <button id="spCheckin20" class="btn btn-secondary btn-sm">20 min</button>
        <button id="spCheckinCancel" class="btn btn-secondary btn-sm">Cancel</button>
      </div>
      <div class="voice-row" style="margin-bottom:8px;">
        <button id="spSosCountdown" class="btn btn-danger btn-sm">SOS in 8s</button>
        <button id="spSosCancel" class="btn btn-secondary btn-sm">Cancel SOS</button>
      </div>
      <div class="voice-row">
        <button id="spGuardianMode" class="btn btn-secondary btn-sm">Open Guardian Mode (demo)</button>
      </div>
    `;
    controlPanel.appendChild(card);

    const btn10 = document.getElementById("spCheckin10");
    const btn20 = document.getElementById("spCheckin20");
    const btnCancel = document.getElementById("spCheckinCancel");
    const btnSos = document.getElementById("spSosCountdown");
    const btnSosCancel = document.getElementById("spSosCancel");
    const btnGuardian = document.getElementById("spGuardianMode");

    if (btn10) btn10.addEventListener("click", () => startCheckinTimer(10));
    if (btn20) btn20.addEventListener("click", () => startCheckinTimer(20));
    if (btnCancel) btnCancel.addEventListener("click", clearCheckinTimer);
    if (btnSos) btnSos.addEventListener("click", () => startSosWithCountdown(8));
    if (btnSosCancel) btnSosCancel.addEventListener("click", cancelSosCountdown);
    if (btnGuardian) btnGuardian.addEventListener("click", openGuardianMode);
  } catch (e) {
    console.error("SafePath v5 enhancements failed to init", e);
  }
});
// === End SafePath v5 Enhancements ===
