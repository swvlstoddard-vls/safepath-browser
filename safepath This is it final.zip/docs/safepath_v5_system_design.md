# SafePath v5 System Design

This document outlines new features like check-in timers, SOS countdown, and guardian mode.
